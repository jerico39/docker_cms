-- phpMyAdmin SQL Dump
-- version 5.2.3
-- https://www.phpmyadmin.net/
--
-- ホスト: db:3306
-- 生成日時: 2026 年 7 月 12 日 21:17
-- サーバのバージョン： 8.4.8
-- PHP のバージョン: 8.3.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- データベース: `laravel`
--

-- --------------------------------------------------------

--
-- テーブルの構造 `cache`
--

CREATE TABLE `cache` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- テーブルのデータのダンプ `cache`
--

INSERT INTO `cache` (`key`, `value`, `expiration`) VALUES
('laravel-cache-356a192b7913b04c54574d18c28d46e6395428ab', 'i:2;', 1776840033),
('laravel-cache-356a192b7913b04c54574d18c28d46e6395428ab:timer', 'i:1776840033;', 1776840033),
('laravel-cache-livewire-rate-limiter:59c76bce899bfe7b296ceeb496afbd0b12a87149', 'i:1;', 1783321086),
('laravel-cache-livewire-rate-limiter:59c76bce899bfe7b296ceeb496afbd0b12a87149:timer', 'i:1783321086;', 1783321086);

-- --------------------------------------------------------

--
-- テーブルの構造 `cache_locks`
--

CREATE TABLE `cache_locks` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- テーブルの構造 `categories`
--

CREATE TABLE `categories` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- テーブルのデータのダンプ `categories`
--

INSERT INTO `categories` (`id`, `name`, `slug`, `created_at`, `updated_at`) VALUES
(1, 'ニュース', 'news', '2026-03-02 02:29:21', '2026-03-02 02:29:21');

-- --------------------------------------------------------

--
-- テーブルの構造 `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- テーブルの構造 `jobs`
--

CREATE TABLE `jobs` (
  `id` bigint UNSIGNED NOT NULL,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint UNSIGNED NOT NULL,
  `reserved_at` int UNSIGNED DEFAULT NULL,
  `available_at` int UNSIGNED NOT NULL,
  `created_at` int UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- テーブルの構造 `job_batches`
--

CREATE TABLE `job_batches` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_jobs` int NOT NULL,
  `pending_jobs` int NOT NULL,
  `failed_jobs` int NOT NULL,
  `failed_job_ids` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` mediumtext COLLATE utf8mb4_unicode_ci,
  `cancelled_at` int DEFAULT NULL,
  `created_at` int NOT NULL,
  `finished_at` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- テーブルの構造 `menus`
--

CREATE TABLE `menus` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `menu_id` bigint UNSIGNED DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sort` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- テーブルのデータのダンプ `menus`
--

INSERT INTO `menus` (`id`, `name`, `slug`, `created_at`, `updated_at`, `menu_id`, `title`, `url`, `sort`) VALUES
(1, 'ヘッダー', 'header', '2026-03-11 07:11:51', '2026-03-12 05:02:40', NULL, NULL, NULL, 0),
(2, 'フッター', 'footer', '2026-03-12 04:21:04', '2026-03-12 05:03:00', NULL, NULL, NULL, 0);

-- --------------------------------------------------------

--
-- テーブルの構造 `menu_items`
--

CREATE TABLE `menu_items` (
  `id` bigint UNSIGNED NOT NULL,
  `menu_id` bigint UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sort` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- テーブルのデータのダンプ `menu_items`
--

INSERT INTO `menu_items` (`id`, `menu_id`, `title`, `url`, `sort`, `created_at`, `updated_at`) VALUES
(1, 1, 'ホーム', '/', 1, '2026-03-11 08:14:00', '2026-03-12 05:03:57'),
(2, 1, 'ニュース', '/news', 2, '2026-03-12 05:03:48', '2026-03-12 05:03:48');

-- --------------------------------------------------------

--
-- テーブルの構造 `migrations`
--

CREATE TABLE `migrations` (
  `id` int UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- テーブルのデータのダンプ `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '0001_01_01_000000_create_users_table', 1),
(2, '0001_01_01_000001_create_cache_table', 1),
(3, '0001_01_01_000002_create_jobs_table', 1),
(5, '2026_02_26_024317_create_pages_table', 2),
(6, '2026_02_26_025102_create_news_table', 3),
(7, '2026_02_26_041633_create_site_settings_table', 3),
(10, '2026_02_27_012900_add_image_to_pages_table', 4),
(11, '2026_03_01_042822_create_categories_table', 5),
(12, '2026_03_01_042836_create_tags_table', 5),
(13, '2026_03_01_044128_create_news_tag_table', 5),
(14, '2026_03_02_025038_add_category_id_to_news_table', 6),
(15, '2026_03_02_025959_add_image_to_news_table', 7),
(16, '2026_03_07_100459_add_role_to_users_table', 8),
(17, '2026_03_10_060947_create_settings_table', 9),
(18, '2026_03_11_060352_create_menus_table', 10),
(19, '2026_03_11_060626_create_menu_items_table', 10),
(20, '2026_03_13_000000_add_menu_id_to_menus_table', 11),
(21, '2026_03_19_145005_create_surveys_table', 12),
(22, '2026_03_19_145010_create_survey_options_table', 13),
(23, '2026_03_19_145012_create_survey_votes_table', 13),
(24, '2026_03_19_145015_create_survey_comments_table', 13),
(25, '2026_04_03_163627_add_survey_option_id_to_survey_comments', 14),
(26, '2026_04_15_113729_add_vote_id_to_survey_comments_table', 15),
(27, '2026_06_20_090244_create_cache_table', 0),
(28, '2026_06_20_090244_create_cache_locks_table', 0),
(29, '2026_06_20_090244_create_categories_table', 0),
(30, '2026_06_20_090244_create_failed_jobs_table', 0),
(31, '2026_06_20_090244_create_job_batches_table', 0),
(32, '2026_06_20_090244_create_jobs_table', 0),
(33, '2026_06_20_090244_create_menu_items_table', 0),
(34, '2026_06_20_090244_create_menus_table', 0),
(35, '2026_06_20_090244_create_news_table', 0),
(36, '2026_06_20_090244_create_news_tag_table', 0),
(37, '2026_06_20_090244_create_pages_table', 0),
(38, '2026_06_20_090244_create_password_reset_tokens_table', 0),
(39, '2026_06_20_090244_create_sessions_table', 0),
(40, '2026_06_20_090244_create_settings_table', 0),
(41, '2026_06_20_090244_create_site_settings_table', 0),
(42, '2026_06_20_090244_create_survey_comments_table', 0),
(43, '2026_06_20_090244_create_survey_options_table', 0),
(44, '2026_06_20_090244_create_survey_votes_table', 0),
(45, '2026_06_20_090244_create_surveys_table', 0),
(46, '2026_06_20_090244_create_tags_table', 0),
(47, '2026_06_20_090244_create_users_table', 0),
(48, '2026_06_20_090247_add_foreign_keys_to_menu_items_table', 0),
(49, '2026_06_20_090247_add_foreign_keys_to_menus_table', 0),
(50, '2026_06_20_090247_add_foreign_keys_to_news_table', 0),
(51, '2026_06_20_090247_add_foreign_keys_to_news_tag_table', 0),
(52, '2026_06_20_090247_add_foreign_keys_to_survey_comments_table', 0),
(53, '2026_06_20_090247_add_foreign_keys_to_survey_options_table', 0),
(54, '2026_06_20_090247_add_foreign_keys_to_survey_votes_table', 0);

-- --------------------------------------------------------

--
-- テーブルの構造 `news`
--

CREATE TABLE `news` (
  `id` bigint UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `published_at` timestamp NULL DEFAULT NULL,
  `is_published` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `category_id` bigint UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- テーブルのデータのダンプ `news`
--

INSERT INTO `news` (`id`, `title`, `slug`, `content`, `image`, `published_at`, `is_published`, `created_at`, `updated_at`, `category_id`) VALUES
(1, '３月２日のニュース', 'news0302', '<p>２０２６年３月２日のニュースです。</p><p>大変なことがおきました。これはすごいです。革命的です。</p><p><figure data-trix-attachment=\"{&quot;contentType&quot;:&quot;image/png&quot;,&quot;filename&quot;:&quot;fish_cheep_super_mario_bros_icon_232942.png&quot;,&quot;filesize&quot;:2598,&quot;height&quot;:512,&quot;href&quot;:&quot;http://localhost:8000/storage/LVwEfmcnpuAlLfU3ONZ9cH3asCvnlENH4nOiuPJ8.png&quot;,&quot;url&quot;:&quot;http://localhost:8000/storage/LVwEfmcnpuAlLfU3ONZ9cH3asCvnlENH4nOiuPJ8.png&quot;,&quot;width&quot;:512}\" data-trix-content-type=\"image/png\" data-trix-attributes=\"{&quot;presentation&quot;:&quot;gallery&quot;}\" class=\"attachment attachment--preview attachment--png\"><a href=\"http://localhost:8000/storage/LVwEfmcnpuAlLfU3ONZ9cH3asCvnlENH4nOiuPJ8.png\"><img src=\"http://localhost:8000/storage/LVwEfmcnpuAlLfU3ONZ9cH3asCvnlENH4nOiuPJ8.png\" width=\"512\" height=\"512\"><figcaption class=\"attachment__caption\"><span class=\"attachment__name\">fish_cheep_super_mario_bros_icon_232942.png</span> <span class=\"attachment__size\">2.54 KB</span></figcaption></a></figure></p><p>世界初のこころみです。</p><p><br></p>', 'pages/TEST-600_400.png', '2026-03-02 05:18:00', 1, '2026-03-02 03:07:31', '2026-03-19 13:23:45', 1),
(2, '３月11日のニュース', 'news0311', '<p>これは大変なニュースです。</p><p>どうしましょう。</p>', NULL, NULL, 0, '2026-03-13 05:01:50', '2026-04-16 17:19:33', 1),
(3, '3月11日のニュース２です。', 'news0311_2', '<p>ニュースを追加しました。</p>', 'pages/toad_super_mario_bros_icon_232934.webp', '2026-03-13 14:30:00', 1, '2026-03-13 05:30:15', '2026-04-16 16:40:29', 1);

-- --------------------------------------------------------

--
-- テーブルの構造 `news_tag`
--

CREATE TABLE `news_tag` (
  `news_id` bigint UNSIGNED NOT NULL,
  `tag_id` bigint UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- テーブルのデータのダンプ `news_tag`
--

INSERT INTO `news_tag` (`news_id`, `tag_id`) VALUES
(1, 1),
(2, 1),
(3, 1);

-- --------------------------------------------------------

--
-- テーブルの構造 `pages`
--

CREATE TABLE `pages` (
  `id` bigint UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_published` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- テーブルのデータのダンプ `pages`
--

INSERT INTO `pages` (`id`, `title`, `slug`, `content`, `image`, `is_published`, `created_at`, `updated_at`) VALUES
(1, 'ホーム画面です。', 'home', '<p>これがTOP画面です。</p><p><figure data-trix-attachment=\"{&quot;contentType&quot;:&quot;image/png&quot;,&quot;filename&quot;:&quot;TEST-600_400.png&quot;,&quot;filesize&quot;:2563,&quot;height&quot;:400,&quot;href&quot;:&quot;http://localhost:8000/storage/Bog9EeIlQTNyhLpVDReICcUUqewPxpGciVzWLxqk.png&quot;,&quot;url&quot;:&quot;http://localhost:8000/storage/Bog9EeIlQTNyhLpVDReICcUUqewPxpGciVzWLxqk.png&quot;,&quot;width&quot;:600}\" data-trix-content-type=\"image/png\" data-trix-attributes=\"{&quot;presentation&quot;:&quot;gallery&quot;}\" class=\"attachment attachment--preview attachment--png\"><a href=\"http://localhost:8000/storage/Bog9EeIlQTNyhLpVDReICcUUqewPxpGciVzWLxqk.png\"><img src=\"http://localhost:8000/storage/Bog9EeIlQTNyhLpVDReICcUUqewPxpGciVzWLxqk.png\" width=\"600\" height=\"400\"><figcaption class=\"attachment__caption\"><span class=\"attachment__name\">TEST-600_400.png</span> <span class=\"attachment__size\">2.5 KB</span></figcaption></a></figure></p>', 'pages/test_1-720_720.jpg', 1, '2026-02-26 07:05:22', '2026-03-01 03:57:33'),
(2, '会社概要', 'company', '<pre>&lt;b&gt;ここは会社概要です&lt;/b&gt;&lt;h2&gt;そうです。&lt;/h2&gt;</pre><p>&lt;p&gt;ここに会社概要が入りますよ。&lt;/p&gt;</p><div class=\"attachment-gallery attachment-gallery--2\"><figure data-trix-attachment=\"{&quot;contentType&quot;:&quot;image/png&quot;,&quot;filename&quot;:&quot;&amp;text=TEST-1200_1200.png&quot;,&quot;filesize&quot;:5270,&quot;height&quot;:1200,&quot;href&quot;:&quot;http://localhost/storage/xaX68ev4GnrcSYS6fXZCSAihS5YzgsGHmpqB0MZy.png&quot;,&quot;url&quot;:&quot;http://localhost/storage/xaX68ev4GnrcSYS6fXZCSAihS5YzgsGHmpqB0MZy.png&quot;,&quot;width&quot;:1200}\" data-trix-content-type=\"image/png\" data-trix-attributes=\"{&quot;presentation&quot;:&quot;gallery&quot;}\" class=\"attachment attachment--preview attachment--png\"><a href=\"http://localhost/storage/xaX68ev4GnrcSYS6fXZCSAihS5YzgsGHmpqB0MZy.png\"><img src=\"http://localhost/storage/xaX68ev4GnrcSYS6fXZCSAihS5YzgsGHmpqB0MZy.png\" width=\"1200\" height=\"1200\"><figcaption class=\"attachment__caption\"><span class=\"attachment__name\">&amp;text=TEST-1200_1200.png</span> <span class=\"attachment__size\">5.15 KB</span></figcaption></a></figure><figure data-trix-attachment=\"{&quot;contentType&quot;:&quot;image/png&quot;,&quot;filename&quot;:&quot;test_image300_300.png&quot;,&quot;filesize&quot;:1299,&quot;height&quot;:300,&quot;href&quot;:&quot;http://localhost/storage/4miV705fKBJyfCgL6kIEkNA5dqac9WUnUOhprnoV.png&quot;,&quot;url&quot;:&quot;http://localhost/storage/4miV705fKBJyfCgL6kIEkNA5dqac9WUnUOhprnoV.png&quot;,&quot;width&quot;:300}\" data-trix-content-type=\"image/png\" data-trix-attributes=\"{&quot;presentation&quot;:&quot;gallery&quot;}\" class=\"attachment attachment--preview attachment--png\"><a href=\"http://localhost/storage/4miV705fKBJyfCgL6kIEkNA5dqac9WUnUOhprnoV.png\"><img src=\"http://localhost/storage/4miV705fKBJyfCgL6kIEkNA5dqac9WUnUOhprnoV.png\" width=\"300\" height=\"300\"><figcaption class=\"attachment__caption\"><span class=\"attachment__name\">test_image300_300.png</span> <span class=\"attachment__size\">1.27 KB</span></figcaption></a></figure></div><h2>ああああああああ</h2><h3>いいいいいいいいいいいいいいい</h3>', NULL, 1, '2026-02-26 08:23:41', '2026-02-27 02:11:09');

-- --------------------------------------------------------

--
-- テーブルの構造 `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- テーブルの構造 `sessions`
--

CREATE TABLE `sessions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- テーブルのデータのダンプ `sessions`
--

INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
('CWFulXIwfcNxmWkGb3tY0ZDhINseAfKQKltvgUWq', 1, '172.30.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36', 'YTo1OntzOjY6Il90b2tlbiI7czo0MDoiNmdWMlYyMTZST2MxeHZRaW5YSFltRWt4eGlQdExidktZM0Y4RjlGdyI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6Mjc6Imh0dHA6Ly9sb2NhbGhvc3Q6ODAwMC9hZG1pbiI7czo1OiJyb3V0ZSI7czozMDoiZmlsYW1lbnQuYWRtaW4ucGFnZXMuZGFzaGJvYXJkIjt9czo1MDoibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiO2k6MTtzOjE3OiJwYXNzd29yZF9oYXNoX3dlYiI7czo2NDoiYTIzMTkzNTU0MGZkYzQzMzYyZWQyYzk0N2U4MmMyYzlmMDdiZGMzOTEzYmRjZTRhNGYzMzI0ZmJiNTk4ZTUwZCI7fQ==', 1783325436),
('WdDeILVAHnPSqE6exEaRmdNREdov4saTqFgVJkV2', 1, '172.30.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', 'YTo1OntzOjY6Il90b2tlbiI7czo0MDoiUXQ5Szk4dnNwUmppZFF5OWpGd2hwY09RSGpMWFpjREJCSktoaDZrWCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzI6Imh0dHA6Ly9sb2NhbGhvc3Q6ODAwMC9hZG1pbi9uZXdzIjtzOjU6InJvdXRlIjtzOjM1OiJmaWxhbWVudC5hZG1pbi5yZXNvdXJjZXMubmV3cy5pbmRleCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fXM6NTA6ImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjtpOjE7czoxNzoicGFzc3dvcmRfaGFzaF93ZWIiO3M6NjQ6ImEyMzE5MzU1NDBmZGM0MzM2MmVkMmM5NDdlODJjMmM5ZjA3YmRjMzkxM2JkY2U0YTRmMzMyNGZiYjU5OGU1MGQiO30=', 1783889843);

-- --------------------------------------------------------

--
-- テーブルの構造 `settings`
--

CREATE TABLE `settings` (
  `id` bigint UNSIGNED NOT NULL,
  `site_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `site_description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `logo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- テーブルのデータのダンプ `settings`
--

INSERT INTO `settings` (`id`, `site_name`, `site_description`, `logo`, `contact_email`, `created_at`, `updated_at`) VALUES
(1, '俺のサイト', 'これは俺のサイトです。', 'site/20210117145205.gif', 'wakai39@gmail.com', '2026-03-10 06:16:24', '2026-04-02 11:58:56');

-- --------------------------------------------------------

--
-- テーブルの構造 `site_settings`
--

CREATE TABLE `site_settings` (
  `id` bigint UNSIGNED NOT NULL,
  `company_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- テーブルの構造 `surveys`
--

CREATE TABLE `surveys` (
  `id` bigint UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- テーブルのデータのダンプ `surveys`
--

INSERT INTO `surveys` (`id`, `title`, `description`, `expires_at`, `created_at`, `updated_at`) VALUES
(3, 'アンケートテスト、好きな選手は？', 'ここにアンケートの説明が入ります。', '2026-04-25 17:06:25', '2026-04-15 11:01:31', '2026-04-21 13:13:12'),
(4, '2027年のスーパーボウル61を制覇するチームは？', '開幕前に優勝予想をしてみよう！', '2026-04-24 15:45:02', '2026-04-22 15:39:49', '2026-04-23 16:59:43');

-- --------------------------------------------------------

--
-- テーブルの構造 `survey_comments`
--

CREATE TABLE `survey_comments` (
  `id` bigint UNSIGNED NOT NULL,
  `vote_id` bigint UNSIGNED NOT NULL,
  `survey_id` bigint UNSIGNED NOT NULL,
  `comment` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `survey_option_id` bigint UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- テーブルのデータのダンプ `survey_comments`
--

INSERT INTO `survey_comments` (`id`, `vote_id`, `survey_id`, `comment`, `created_at`, `updated_at`, `survey_option_id`) VALUES
(21, 57, 3, 'コメントの追加です。', '2026-04-15 11:54:55', '2026-04-15 11:54:55', 34),
(22, 59, 3, '追加へのコメント', '2026-04-15 13:19:13', '2026-04-15 13:19:13', 36),
(23, 61, 3, 'マホームズしか勝たん', '2026-04-16 10:59:44', '2026-04-16 10:59:44', 30),
(24, 63, 3, '永遠に不滅です。', '2026-04-16 13:38:33', '2026-04-16 13:38:33', 33),
(25, 64, 3, 'やはりマリオが一番でしょう。しかし、スーパーマリオは選手ではありません。\r\nそこが問題になります。果たして、この投票企画に彼を加えていいのでしょうか？\r\nそれは私にも分かりませんが、果たしてこのコメント欄、一体何文字書けばいいのでしょう。制限を設けるべきか、そこが問題です。', '2026-04-16 14:03:06', '2026-04-16 14:03:06', 37),
(26, 65, 3, '012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789', '2026-04-16 14:16:31', '2026-04-16 14:16:31', 37),
(27, 66, 3, '0123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789', '2026-04-16 14:16:54', '2026-04-16 14:16:54', 33),
(28, 67, 3, 'これしかない。', '2026-04-16 14:23:00', '2026-04-16 14:23:00', 35),
(29, 68, 3, '0123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789', '2026-04-16 15:33:28', '2026-04-16 15:33:28', 31),
(30, 73, 3, 'ブレイディ様しか勝たん', '2026-04-20 17:02:57', '2026-04-20 17:02:57', 34),
(31, 74, 4, 'そりゃくるでしょう。念願のスーパーボウル制覇', '2026-04-22 15:40:57', '2026-04-22 15:40:57', 59);

-- --------------------------------------------------------

--
-- テーブルの構造 `survey_options`
--

CREATE TABLE `survey_options` (
  `id` bigint UNSIGNED NOT NULL,
  `survey_id` bigint UNSIGNED NOT NULL,
  `option_text` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_user_generated` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- テーブルのデータのダンプ `survey_options`
--

INSERT INTO `survey_options` (`id`, `survey_id`, `option_text`, `is_user_generated`, `created_at`, `updated_at`) VALUES
(30, 3, 'パトリック・マホームズ', 0, '2026-04-15 11:01:31', '2026-04-15 11:01:31'),
(31, 3, 'サム・ダーノルド', 0, '2026-04-15 11:01:31', '2026-04-15 11:01:31'),
(32, 3, 'ジェイレン・ハーツ', 0, '2026-04-15 11:01:31', '2026-04-15 11:01:31'),
(33, 3, 'アーロン・ロジャース', 0, '2026-04-15 11:01:31', '2026-04-15 11:01:31'),
(34, 3, 'トム・ブレイディ', 1, '2026-04-15 11:13:12', '2026-04-15 11:13:12'),
(35, 3, 'ルドウィック', 1, '2026-04-15 13:14:08', '2026-04-15 13:14:08'),
(36, 3, '追加です', 1, '2026-04-15 13:19:13', '2026-04-15 13:19:13'),
(37, 3, 'スーパーマリオ', 1, '2026-04-16 13:19:27', '2026-04-16 13:19:27'),
(38, 3, 'ssss', 1, '2026-04-16 15:38:02', '2026-04-16 15:38:02'),
(39, 3, 'クッパ', 0, '2026-04-22 14:47:04', '2026-04-22 14:47:04'),
(50, 3, 'マリオ', 0, '2026-04-22 14:53:14', '2026-04-22 14:53:14'),
(51, 3, 'キノピオ', 0, '2026-04-22 14:53:14', '2026-04-22 14:53:14'),
(52, 3, 'ピーチ', 0, '2026-04-22 14:53:14', '2026-04-22 14:53:14'),
(53, 3, 'ルイージ', 0, '2026-04-22 14:53:14', '2026-04-22 14:53:14'),
(54, 3, 'のこのこ', 0, '2026-04-22 14:53:14', '2026-04-22 14:53:14'),
(55, 3, '子クッパ', 0, '2026-04-22 14:54:31', '2026-04-22 14:54:31'),
(56, 3, 'まごクッパ', 0, '2026-04-22 14:54:31', '2026-04-22 14:54:31'),
(57, 3, 'ひまごクッパ', 0, '2026-04-22 14:54:31', '2026-04-22 14:54:31'),
(58, 4, 'ジェッツ', 0, '2026-04-22 15:39:49', '2026-04-22 15:39:49'),
(59, 4, 'ニューヨーク・ジェッツ', 0, '2026-04-22 15:40:05', '2026-04-22 15:40:05'),
(60, 4, 'ニューヨークの緑の方', 0, '2026-04-22 15:40:05', '2026-04-22 15:40:05'),
(61, 4, 'NYJ', 0, '2026-04-22 15:40:05', '2026-04-22 15:40:05'),
(62, 4, 'ジーノ・スミスしか勝たん！', 0, '2026-04-22 15:40:05', '2026-04-22 15:40:05'),
(63, 4, '１５シーズンプレーオフに出てないチーム', 0, '2026-04-22 15:40:05', '2026-04-22 15:40:05'),
(64, 4, 'ニューイングランド・ペイトリオッツ', 1, '2026-04-22 15:41:49', '2026-04-22 15:41:49');

-- --------------------------------------------------------

--
-- テーブルの構造 `survey_votes`
--

CREATE TABLE `survey_votes` (
  `id` bigint UNSIGNED NOT NULL,
  `survey_id` bigint UNSIGNED NOT NULL,
  `survey_option_id` bigint UNSIGNED NOT NULL,
  `user_ip` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- テーブルのデータのダンプ `survey_votes`
--

INSERT INTO `survey_votes` (`id`, `survey_id`, `survey_option_id`, `user_ip`, `created_at`, `updated_at`) VALUES
(53, 3, 33, '172.30.0.1', '2026-04-15 11:10:58', '2026-04-15 11:10:58'),
(54, 3, 31, '172.30.0.1', '2026-04-15 11:11:10', '2026-04-15 11:11:10'),
(55, 3, 34, '172.30.0.1', '2026-04-15 11:13:12', '2026-04-15 11:13:12'),
(56, 3, 34, '172.30.0.1', '2026-04-15 11:53:34', '2026-04-15 11:53:34'),
(57, 3, 34, '172.30.0.1', '2026-04-15 11:54:55', '2026-04-15 11:54:55'),
(58, 3, 35, '172.30.0.1', '2026-04-15 13:14:08', '2026-04-15 13:14:08'),
(59, 3, 36, '172.30.0.1', '2026-04-15 13:19:13', '2026-04-15 13:19:13'),
(60, 3, 30, '172.30.0.1', '2026-04-16 10:56:03', '2026-04-16 10:56:03'),
(61, 3, 30, '172.30.0.1', '2026-04-16 10:59:44', '2026-04-16 10:59:44'),
(62, 3, 37, '172.30.0.1', '2026-04-16 13:19:27', '2026-04-16 13:19:27'),
(63, 3, 33, '172.30.0.1', '2026-04-16 13:38:33', '2026-04-16 13:38:33'),
(64, 3, 37, '172.30.0.1', '2026-04-16 14:03:06', '2026-04-16 14:03:06'),
(65, 3, 37, '172.30.0.1', '2026-04-16 14:16:31', '2026-04-16 14:16:31'),
(66, 3, 33, '172.30.0.1', '2026-04-16 14:16:54', '2026-04-16 14:16:54'),
(67, 3, 35, '172.30.0.1', '2026-04-16 14:23:00', '2026-04-16 14:23:00'),
(68, 3, 31, '172.30.0.1', '2026-04-16 15:33:28', '2026-04-16 15:33:28'),
(69, 3, 38, '172.30.0.1', '2026-04-16 15:38:02', '2026-04-16 15:38:02'),
(70, 3, 31, '172.30.0.1', '2026-04-20 17:02:39', '2026-04-20 17:02:39'),
(71, 3, 31, '172.30.0.1', '2026-04-20 17:02:42', '2026-04-20 17:02:42'),
(72, 3, 35, '172.30.0.1', '2026-04-20 17:02:45', '2026-04-20 17:02:45'),
(73, 3, 34, '172.30.0.1', '2026-04-20 17:02:57', '2026-04-20 17:02:57'),
(74, 4, 59, '172.30.0.1', '2026-04-22 15:40:57', '2026-04-22 15:40:57'),
(75, 4, 64, '172.30.0.1', '2026-04-22 15:41:49', '2026-04-22 15:41:49');

-- --------------------------------------------------------

--
-- テーブルの構造 `tags`
--

CREATE TABLE `tags` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- テーブルのデータのダンプ `tags`
--

INSERT INTO `tags` (`id`, `name`, `slug`, `created_at`, `updated_at`) VALUES
(1, '会社', 'company', '2026-03-02 02:43:54', '2026-03-02 02:43:54'),
(2, '管理部', 'kanribu', '2026-03-02 08:06:45', '2026-03-02 08:06:45');

-- --------------------------------------------------------

--
-- テーブルの構造 `users`
--

CREATE TABLE `users` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `role` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'editor'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- テーブルのデータのダンプ `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`, `role`) VALUES
(1, 'user', 'wakai39@gmail.com', NULL, '$2y$12$fnVfUnsoys3dhrLUfVsVcODkhQu2L/dLYe.yBWt/5QFtZnRZccWAi', 'fLIhKoDC2Hj4tJyxCGOOqhP98slfrTtb7uud3jGoygIawelMUcWgX6ILos41', '2026-02-25 08:41:13', '2026-02-25 08:41:13', 'editor'),
(2, '試験太郎', 'wakai392@gmail.com', NULL, '$2y$12$OZqbeME2vfzUnPiEF9yrRubALNGNP7v9RmEpcHz4jqilAbyAA0eku', NULL, '2026-03-09 03:34:30', '2026-03-09 03:34:30', 'editor');

--
-- ダンプしたテーブルのインデックス
--

--
-- テーブルのインデックス `cache`
--
ALTER TABLE `cache`
  ADD PRIMARY KEY (`key`),
  ADD KEY `cache_expiration_index` (`expiration`);

--
-- テーブルのインデックス `cache_locks`
--
ALTER TABLE `cache_locks`
  ADD PRIMARY KEY (`key`),
  ADD KEY `cache_locks_expiration_index` (`expiration`);

--
-- テーブルのインデックス `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `categories_slug_unique` (`slug`);

--
-- テーブルのインデックス `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- テーブルのインデックス `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `jobs_queue_index` (`queue`);

--
-- テーブルのインデックス `job_batches`
--
ALTER TABLE `job_batches`
  ADD PRIMARY KEY (`id`);

--
-- テーブルのインデックス `menus`
--
ALTER TABLE `menus`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `menus_slug_unique` (`slug`),
  ADD KEY `menus_menu_id_foreign` (`menu_id`);

--
-- テーブルのインデックス `menu_items`
--
ALTER TABLE `menu_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `menu_items_menu_id_foreign` (`menu_id`);

--
-- テーブルのインデックス `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- テーブルのインデックス `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `news_slug_unique` (`slug`),
  ADD KEY `news_category_id_foreign` (`category_id`);

--
-- テーブルのインデックス `news_tag`
--
ALTER TABLE `news_tag`
  ADD KEY `news_tag_news_id_foreign` (`news_id`),
  ADD KEY `news_tag_tag_id_foreign` (`tag_id`);

--
-- テーブルのインデックス `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `pages_slug_unique` (`slug`);

--
-- テーブルのインデックス `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- テーブルのインデックス `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sessions_user_id_index` (`user_id`),
  ADD KEY `sessions_last_activity_index` (`last_activity`);

--
-- テーブルのインデックス `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- テーブルのインデックス `site_settings`
--
ALTER TABLE `site_settings`
  ADD PRIMARY KEY (`id`);

--
-- テーブルのインデックス `surveys`
--
ALTER TABLE `surveys`
  ADD PRIMARY KEY (`id`);

--
-- テーブルのインデックス `survey_comments`
--
ALTER TABLE `survey_comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `survey_comments_survey_id_foreign` (`survey_id`),
  ADD KEY `survey_comments_survey_option_id_foreign` (`survey_option_id`),
  ADD KEY `survey_comments_vote_id_foreign` (`vote_id`);

--
-- テーブルのインデックス `survey_options`
--
ALTER TABLE `survey_options`
  ADD PRIMARY KEY (`id`),
  ADD KEY `survey_options_survey_id_foreign` (`survey_id`);

--
-- テーブルのインデックス `survey_votes`
--
ALTER TABLE `survey_votes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `survey_votes_survey_option_id_foreign` (`survey_option_id`),
  ADD KEY `survey_votes_survey_id_foreign` (`survey_id`);

--
-- テーブルのインデックス `tags`
--
ALTER TABLE `tags`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `tags_slug_unique` (`slug`);

--
-- テーブルのインデックス `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- ダンプしたテーブルの AUTO_INCREMENT
--

--
-- テーブルの AUTO_INCREMENT `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- テーブルの AUTO_INCREMENT `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- テーブルの AUTO_INCREMENT `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- テーブルの AUTO_INCREMENT `menus`
--
ALTER TABLE `menus`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- テーブルの AUTO_INCREMENT `menu_items`
--
ALTER TABLE `menu_items`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- テーブルの AUTO_INCREMENT `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;

--
-- テーブルの AUTO_INCREMENT `news`
--
ALTER TABLE `news`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- テーブルの AUTO_INCREMENT `pages`
--
ALTER TABLE `pages`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- テーブルの AUTO_INCREMENT `settings`
--
ALTER TABLE `settings`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- テーブルの AUTO_INCREMENT `site_settings`
--
ALTER TABLE `site_settings`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- テーブルの AUTO_INCREMENT `surveys`
--
ALTER TABLE `surveys`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- テーブルの AUTO_INCREMENT `survey_comments`
--
ALTER TABLE `survey_comments`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- テーブルの AUTO_INCREMENT `survey_options`
--
ALTER TABLE `survey_options`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=65;

--
-- テーブルの AUTO_INCREMENT `survey_votes`
--
ALTER TABLE `survey_votes`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=76;

--
-- テーブルの AUTO_INCREMENT `tags`
--
ALTER TABLE `tags`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- テーブルの AUTO_INCREMENT `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- ダンプしたテーブルの制約
--

--
-- テーブルの制約 `menus`
--
ALTER TABLE `menus`
  ADD CONSTRAINT `menus_menu_id_foreign` FOREIGN KEY (`menu_id`) REFERENCES `menus` (`id`) ON DELETE CASCADE;

--
-- テーブルの制約 `menu_items`
--
ALTER TABLE `menu_items`
  ADD CONSTRAINT `menu_items_menu_id_foreign` FOREIGN KEY (`menu_id`) REFERENCES `menus` (`id`) ON DELETE CASCADE;

--
-- テーブルの制約 `news`
--
ALTER TABLE `news`
  ADD CONSTRAINT `news_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL;

--
-- テーブルの制約 `news_tag`
--
ALTER TABLE `news_tag`
  ADD CONSTRAINT `news_tag_news_id_foreign` FOREIGN KEY (`news_id`) REFERENCES `news` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `news_tag_tag_id_foreign` FOREIGN KEY (`tag_id`) REFERENCES `tags` (`id`) ON DELETE CASCADE;

--
-- テーブルの制約 `survey_comments`
--
ALTER TABLE `survey_comments`
  ADD CONSTRAINT `survey_comments_survey_id_foreign` FOREIGN KEY (`survey_id`) REFERENCES `surveys` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `survey_comments_survey_option_id_foreign` FOREIGN KEY (`survey_option_id`) REFERENCES `survey_options` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `survey_comments_vote_id_foreign` FOREIGN KEY (`vote_id`) REFERENCES `survey_votes` (`id`) ON DELETE CASCADE;

--
-- テーブルの制約 `survey_options`
--
ALTER TABLE `survey_options`
  ADD CONSTRAINT `survey_options_survey_id_foreign` FOREIGN KEY (`survey_id`) REFERENCES `surveys` (`id`) ON DELETE CASCADE;

--
-- テーブルの制約 `survey_votes`
--
ALTER TABLE `survey_votes`
  ADD CONSTRAINT `survey_votes_survey_id_foreign` FOREIGN KEY (`survey_id`) REFERENCES `surveys` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `survey_votes_survey_option_id_foreign` FOREIGN KEY (`survey_option_id`) REFERENCES `survey_options` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
